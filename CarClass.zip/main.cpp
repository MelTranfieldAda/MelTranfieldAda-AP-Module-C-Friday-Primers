#include <iostream>

class Car { 
  private:
    std::string color;
    std::string make;
    bool isEngineOn = false;
    bool isLocked = false;

  public:
    void set_colour(std::string c) { color = c; }
    std::string get_colour() {return color;}
    void set_make(std::string m) { make = m; }
    std::string get_make() { return make; }
    void engine_on() {
      if (isEngineOn) std::cout << "Engine is already Running!" << std::endl; 
      isEngineOn = true;
    }
    void engine_off() {
      if (!isEngineOn) std::cout << "Engine is already off!" << std::endl; 
      isEngineOn = false;
    }
    void locked(bool l) {
      if (l && isLocked) std::cout << "Sorry, the car is already locked" << std::endl;
      if (!l && !isLocked) std::cout << "Sorry, the car is already unlocked" << std::endl;
      isLocked = l;
    }
    void status() {
      std::cout << "Car Status: colour: " << color << ", make: " << make << ", engine: " << (isEngineOn ? "Running" : "Off") << ", " << (isLocked ? "Locked" : "Unlocked") << std::endl;
    }
};

int main() {
  int selectedOption;
  Car car = Car();
  car.set_colour("Blue");
  car.set_make("Honda");
  do {
    car.status();
    std::cout << "1. Turn engine on\n2. Turn engine off\n3. Lock car\n4. Unlock car\nPlease select an option (or 0 to finish): ";
    std::cin >> selectedOption;

    if (selectedOption == 1) {
      car.engine_on();
    } else if (selectedOption == 2) {
      car.engine_off();
    } else if (selectedOption == 3) {
      car.locked(true);
    } else if (selectedOption == 4) {
      car.locked(false);
    }
  } while (selectedOption != 0);
  
}